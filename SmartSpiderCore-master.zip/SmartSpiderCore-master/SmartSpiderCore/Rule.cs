﻿
namespace SmartSpiderCore
{
    public abstract class Rule
    {
        public abstract Content Exec(Content content);
    }
}
