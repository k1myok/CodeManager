﻿namespace SmartSpiderCore.In.ActiveMQMessage
{
    public abstract class MessageContext
    {
        public Response Response { get; set; }
    }
}
