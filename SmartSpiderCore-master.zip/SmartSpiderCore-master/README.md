# SmartSpiderCore 
SmartSpider爬虫引擎内核版，全新的设计理念，真正的极简版本！

# 运行示例
SmartSpiderCore.WinConsole.exe Task/其他.特别行政区.北京市.bj.qu114.com.保洁.xml

# 运行界面
![运行界面](https://raw.githubusercontent.com/ljja/SmartSpiderCore/master/doc/run-example.png)

# 采集结果
![采集结果](https://raw.githubusercontent.com/ljja/SmartSpiderCore/master/doc/run-result.png)
