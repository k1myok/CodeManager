﻿using System;

namespace GMF.Demo.Core.Data.T4
{
    public class HelloWorld3
    {
        private string _word;

        public HelloWorld3(string word)
        {
            _word = word;
        }
    }
}
