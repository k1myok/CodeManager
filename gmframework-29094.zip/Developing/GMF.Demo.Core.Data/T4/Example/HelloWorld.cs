﻿using System;

namespace GMF.Demo.Core.Data.T4
{
    public class HelloWorld
    {
        private string _word;

        public HelloWorld(string word)
        {
            _word = word;
        }
    }
}
